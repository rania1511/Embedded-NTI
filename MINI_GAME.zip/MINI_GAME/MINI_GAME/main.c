/*
 * MINI_GAME.c
 *
 * Created: 7/26/2023 10:30:37 PM
 * Author : Lenovo
 */ 

#include <avr/io.h>
#include <util/delay.h>
#include "DIO.h"
#include "LCD.h"

int main(void)
{
uint8 container[] = {
	0B00000,
	0B00000,
	0B11111,
	0B11111,
	0B01110,
	0B01110,
	0B01110,
	0B01110
};
uint8 fruit[] = {
	0B00010,
	0B00100,
	0B00100,
	0B01110,
	0B11111,
	0B11111,
	0B01110,
	0B00100
};
LCD_Init();
uint8 i=0;
uint8 pressed=0;
uint8 pressed_flag=0;
uint8 score='0';
DIO_SetPinDir(DIO_PORTD ,DIO_PIN0 ,DIO_PIN_INPUT);
    while (1) 
    {
		pressed_flag=0;
		pressed=0;
		i=0;
		LCD_ClearScreen();
		while(pressed_flag==0)
		{
		for(i=0;i<16;i++)
		{
			pressed =DIO_GetPinVal(DIO_PORTD ,DIO_PIN0);
			if(pressed==1)
			{
				pressed_flag=1;
				break;
			}
			LCD_GoTo(0, 0);
			LCD_WriteString("score:");
			LCD_GoTo(0, 6);
			LCD_WriteChar(score);
			LCD_WriteSpecialChar(container,72,1);
			LCD_WriteSpecialChar(fruit,i,0);
			_delay_ms(2000);
			LCD_ClearScreen();
		}
		}
		while(pressed_flag==1)
		{
			pressed_flag=0;
			LCD_GoTo(0, 0);
			LCD_WriteString("score:");
			LCD_GoTo(0, 6);
			LCD_WriteChar(score);
			LCD_WriteSpecialChar(container,72,1);
			LCD_WriteSpecialChar(fruit,i+64,0);
			if(i>=6 && i<=8)
			{
			 score++;
			 LCD_GoTo(0, 6);
			 LCD_WriteChar(score);
			}
		}
    }
}

