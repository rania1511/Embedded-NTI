/*
 * CALCULATOR.c
 *
 * Created: 7/24/2023 1:14:46 PM
 * Author : Lenovo
 */ 

#include <avr/io.h>
#include <util/delay.h>
#include "KEYPAD.h"
#include "LCD.h"

int main(void)
{
	KeyPad_Init();
	LCD_Init();
	uint8 arr[16];
	uint8 sizess;
	uint8 i=0;
    uint8 index;
    uint8 operation='x';
	
    while (1) 
    {
		uint8 y=KeyPad_GetChar();
		if(y=='c')
		{
			LCD_ClearScreen();
			i=0;
		}
		if(y!=' ' && y!= '=' && y!='c')
		{
		LCD_WriteChar(y);
		arr[i]=y;
		i++;
		}
		if(y=='=')
		{
			operation='x';
			sizess=i;
			LCD_GoTo(1 , 0);
			LCD_WriteChar('=');
			
			   while(operation!='0')
			   {
				   index=searching(arr,operation,sizess);
				   if(index !=0){
				   operation=arr[index];}
				   if (index!=0)
				   {
					   
					   
					   arr[index-1]= operate(operation,index,arr);
					   arr[index]=' ';
					   arr[index+1]=' ';
					   
					   Remove_Spaces(arr,sizess);
					   sizess=sizess-2;
					   
				   }
				   else if(index==0 && operation=='x')
				   {
					   operation='/';
				   }
				   else if(index==0 && operation=='/')
				   {
				     operation='+';
				   }

				   else if(index==0 && operation=='+')
				   {
					   operation='-';
				   }
				   else
				   {
					   operation='0';
					   arr[0]=arr[0]-'0';
					   LCD_WriteInteger(arr[0]);
					   _delay_ms(5000);
					   LCD_ClearScreen();
					   i=0;
				   }
			   }
			   

		}
    }
}

