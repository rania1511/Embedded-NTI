/*
 * CALCULATOR.h
 *
 * Created: 7/24/2023 1:16:58 PM
 *  Author: Lenovo
 */ 
#include "DIO.h"

#ifndef CALCULATOR_H_
#define CALCULATOR_H_

uint8 searching (uint8 arr[],uint8 item,uint8 size);
void Remove_Spaces (uint8 arr[],uint8 size);
uint8 operate(uint8 operation,uint8 index,uint8 arr[]);

#endif /* CALCULATOR_H_ */