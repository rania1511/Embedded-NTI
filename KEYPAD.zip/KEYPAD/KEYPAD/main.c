/*
 * KEYPAD.c
 *
 * Created: 7/24/2023 10:25:51 AM
 * Author : Lenovo
 */ 

#include <avr/io.h>
#include "KEYPAD.h"
#include "LCD.h"

int main(void)
{
    KeyPad_Init();
	LCD_Init();
	
    while (1) 
    {
		uint8 x=KeyPad_GetChar();
		if(x!=' '){
		LCD_WriteChar(x);}
    }
}

