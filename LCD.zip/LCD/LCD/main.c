/*
 * LCD.c
 *
 * Created: 7/23/2023 11:42:19 AM
 * Author : Lenovo
 */ 

#include <avr/io.h>
#include "LCD.h"

int main(void)
{
	uint8 CustomChar[8] = {
		0x00,0x1b,0x15,0x11,0x0a,0x04,0x00,0x00
	};

    LCD_Init();
	uint8* str="Rania";
	LCD_WriteString(str);
	LCD_GoTo(1 , 0);
	LCD_WriteInteger(42077);
	LCD_WriteSpecialChar(CustomChar,5,0);
    while (1) 
    {

    }
}

