/*
 * SHORT_STORY.c
 *
 * Created: 7/24/2023 1:26:53 PM
 * Author : Lenovo
 */ 

#include <avr/io.h>
#include <util/delay.h>
#include "DIO.h"
#include "LCD.h"
#include "SHORT_STORY.h"


int main(void)
{
    uint8 boy_idle[] = {0B01110, 0B01110,0B00100,0B01110,0B10101,0B00100,0B01010,0B10001};
	uint8 gun[] = {0B00000,0B00000,0B01111,0B11111,0B11000,0B11000,0B00000,0B00000};
	uint8 bullet[] = {0B00000,0B00000,0B01100,0B01110,0B01100,0B00000,0B00000,0B00000};
	uint8 boy_dance[] = {0B01110,0B01110,0B01110,0B10101,0B01110,0B00100,0B01010,0B10001};	
	uint8 ghost[] = {0B01110,0B10101,0B11111,0B11011,0B01110,0B01110,0B00000,0B00000};
	uint8 i=2;
	
	LCD_Init();	
    while (1) 
    {
		
	LCD_ClearScreen();
	LCD_WriteString(" disclaimer !!!");
	_delay_ms(5000);	
	LCD_ClearScreen();
	_delay_ms(5000);
	LCD_WriteString(" don't try this");
	LCD_GoTo(second_column, row_1);
	LCD_WriteString(" at home");
	_delay_ms(10000);
	LCD_ClearScreen();
	_delay_ms(10000);

		for(i=gun_location+1;i<boy2_location-1;i++)
		{
			LCD_WriteSpecialChar(boy_idle,boy1_location,memory_location1);
			LCD_WriteSpecialChar(gun,gun_location,memory_location2);
			LCD_WriteSpecialChar(boy_idle,boy2_location,memory_location1);
			LCD_WriteSpecialChar(bullet,i+1,memory_location3);
			LCD_WriteSpecialChar(bullet,i,memory_location3);
			LCD_GoTo(second_column, row_3);
			LCD_WriteString("pew..pew...pew");
			_delay_ms(2000);
			LCD_ClearScreen();
		}
		
		_delay_ms(2000);
		LCD_WriteSpecialChar(ghost,boy2_location,memory_location4);
		
		dancing(boy_idle,boy_dance,boy1_location);
			
		_delay_ms(10000);
    }
}

