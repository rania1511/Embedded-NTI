/*
 * SHORT_STORY.h
 *
 * Created: 7/24/2023 1:28:07 PM
 *  Author: Lenovo
 */ 

#ifndef SHORT_STORY_H_
#define SHORT_STORY_H_
#include "DIO.h"

#define boy1_location 6
#define boy2_location 15
#define gun_location 7

#define memory_location1 0
#define memory_location2 1
#define memory_location3 2
#define memory_location4 3

#define first_column 0
#define second_column 1

#define row_1 0
#define row_16 15
#define row_5 6
#define row_3 2

void dancing(uint8 move1[],uint8 move2[],uint8 location);


#endif /* SHORT_STORY_H_ */