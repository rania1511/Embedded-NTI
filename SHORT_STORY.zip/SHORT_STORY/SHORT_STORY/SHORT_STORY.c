/*
 * SHORT_STORY.c
 *
 * Created: 7/24/2023 1:27:45 PM
 *  Author: Lenovo
 */ 
#include "SHORT_STORY.h"
#include <util/delay.h>

void dancing(uint8 move1[],uint8 move2[],uint8 location)
{
	uint8 i;
	for(i=0;i<4;i++){
		LCD_WriteSpecialChar(move1,location,memory_location1);
		_delay_ms(2000);
		LCD_WriteSpecialChar(move2,location,memory_location1);
		_delay_ms(2000);
	}

}